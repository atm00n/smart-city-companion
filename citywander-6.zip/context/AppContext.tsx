import React, { createContext, useContext, useState } from 'react';
import { Booking, TravelPackage } from '../types';
import { PACKAGES_DATA } from '../constants';

interface AppContextType {
  bookmarks: string[];
  toggleBookmark: (id: string) => void;
  bookings: Booking[];
  addBooking: (booking: Booking) => void;
  packages: TravelPackage[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([
    { id: 'b1', packageId: 'p1', customerName: 'Rahul Sharma', email: 'rahul@example.com', date: '2023-12-01', status: 'Confirmed' },
    { id: 'b2', packageId: 'p3', customerName: 'Priya Patel', email: 'priya@example.com', date: '2023-11-15', status: 'Pending' }
  ]);
  const [packages] = useState<TravelPackage[]>(PACKAGES_DATA);

  const toggleBookmark = (id: string) => {
    setBookmarks(prev => 
      prev.includes(id) ? prev.filter(b => b !== id) : [...prev, id]
    );
  };

  const addBooking = (booking: Booking) => {
    setBookings(prev => [booking, ...prev]);
  };

  return (
    <AppContext.Provider value={{ bookmarks, toggleBookmark, bookings, addBooking, packages }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};