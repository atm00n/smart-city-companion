export enum PackageCategory {
  ADVENTURE = 'Adventure',
  HONEYMOON = 'Honeymoon',
  SPIRITUAL = 'Spiritual',
  RELAXATION = 'Relaxation',
  HERITAGE = 'Heritage'
}

export interface ItineraryDay {
  day: number;
  title: string;
  description: string;
}

export interface TravelPackage {
  id: string;
  title: string;
  location: string;
  price: number;
  durationDays: number;
  category: PackageCategory;
  rating: number;
  image: string;
  description: string;
  itinerary: ItineraryDay[];
  featured?: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content?: string;
  author: string;
  date: string;
  image: string;
  category: string;
}

export interface Booking {
  id: string;
  packageId: string;
  customerName: string;
  email: string;
  date: string;
  status: 'Pending' | 'Confirmed' | 'Cancelled';
}

export interface TransportOption {
  mode: 'Flight' | 'Train' | 'Bus' | 'Car';
  duration: string;
  price: string;
  icon: string;
}