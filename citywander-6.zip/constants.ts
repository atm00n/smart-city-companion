import { TravelPackage, PackageCategory, BlogPost } from './types';

export const PACKAGES_DATA: TravelPackage[] = [
  {
    id: 'p1',
    title: 'Majestic Kerala Houseboat',
    location: 'Alleppey, Kerala',
    price: 25000,
    durationDays: 5,
    category: PackageCategory.RELAXATION,
    rating: 4.8,
    image: 'https://picsum.photos/seed/kerala/800/600',
    description: 'Experience the serene backwaters of Kerala in a luxury houseboat. Enjoy authentic cuisine and sunset views.',
    featured: true,
    itinerary: [
      { day: 1, title: 'Arrival in Cochin', description: 'Transfer to hotel and evening walk at Fort Kochi.' },
      { day: 2, title: 'Munnar Hills', description: 'Drive to Munnar, visit tea gardens.' },
      { day: 3, title: 'The Houseboat', description: 'Board the houseboat in Alleppey for an overnight cruise.' },
      { day: 4, title: 'Beach Day', description: 'Relax at Marari beach.' },
      { day: 5, title: 'Departure', description: 'Transfer to airport.' }
    ]
  },
  {
    id: 'p2',
    title: 'Jaipur Royal Heritage',
    location: 'Jaipur, Rajasthan',
    price: 18000,
    durationDays: 4,
    category: PackageCategory.HERITAGE,
    rating: 4.6,
    image: 'https://picsum.photos/seed/jaipur/800/600',
    description: 'Walk through the Pink City, visit Amber Fort, and dine like royalty.',
    featured: true,
    itinerary: [
      { day: 1, title: 'Welcome to Pink City', description: 'Check-in to heritage haveli.' },
      { day: 2, title: 'Amber Fort', description: 'Elephant ride and fort tour.' },
      { day: 3, title: 'City Palace', description: 'Museum tour and local markets.' },
      { day: 4, title: 'Departure', description: 'Breakfast and departure.' }
    ]
  },
  {
    id: 'p3',
    title: 'Manali Adventure Trek',
    location: 'Manali, Himachal Pradesh',
    price: 15000,
    durationDays: 6,
    category: PackageCategory.ADVENTURE,
    rating: 4.9,
    image: 'https://picsum.photos/seed/manali/800/600',
    description: 'Snow-capped peaks, paragliding, and river rafting for the thrill seekers.',
    itinerary: [
      { day: 1, title: 'Arrival', description: 'Reach Manali base camp.' },
      { day: 2, title: 'Acclimatization', description: 'Short trek to Jogini falls.' },
      { day: 3, title: 'Solang Valley', description: 'Paragliding and skiing activities.' },
      { day: 4, title: 'Rohtang Pass', description: 'Visit the snow point.' },
      { day: 5, title: 'Rafting', description: 'River rafting in Kullu.' },
      { day: 6, title: 'Departure', description: 'Overnight bus to Delhi.' }
    ]
  },
  {
    id: 'p4',
    title: 'Spiritual Varanasi',
    location: 'Varanasi, UP',
    price: 12000,
    durationDays: 3,
    category: PackageCategory.SPIRITUAL,
    rating: 4.7,
    image: 'https://picsum.photos/seed/varanasi/800/600',
    description: 'Witness the Ganga Aarti and explore the ancient Ghats.',
    itinerary: [
      { day: 1, title: 'Arrival', description: 'Evening Ganga Aarti from a boat.' },
      { day: 2, title: 'Temple Tour', description: 'Kashi Vishwanath and Sarnath tour.' },
      { day: 3, title: 'Departure', description: 'Morning boat ride and departure.' }
    ]
  },
  {
    id: 'p5',
    title: 'Goa Sun & Sand',
    location: 'North Goa',
    price: 22000,
    durationDays: 5,
    category: PackageCategory.RELAXATION,
    rating: 4.5,
    image: 'https://picsum.photos/seed/goa/800/600',
    description: 'Parties, beaches, and Portuguese architecture.',
    itinerary: [
      { day: 1, title: 'Arrival', description: 'Check in near Baga Beach.' },
      { day: 2, title: 'North Goa', description: 'Fort Aguada and beaches.' },
      { day: 3, title: 'South Goa', description: 'Old Goa churches.' },
      { day: 4, title: 'Leisure', description: 'Water sports.' },
      { day: 5, title: 'Departure', description: 'Fly out from Dabolim.' }
    ]
  },
  {
    id: 'p6',
    title: 'Mumbai Dream City',
    location: 'Mumbai, Maharashtra',
    price: 20000,
    durationDays: 3,
    category: PackageCategory.HERITAGE,
    rating: 4.7,
    image: 'https://picsum.photos/seed/mumbai/800/600',
    description: 'Explore the gateway of India, Marine Drive, and the bustling streets of Colaba.',
    featured: true,
    itinerary: [
      { day: 1, title: 'South Mumbai', description: 'Gateway of India, Taj Palace, and Colaba Causeway.' },
      { day: 2, title: 'Culture & Arts', description: 'Elephanta Caves ferry and Jehangir Art Gallery.' },
      { day: 3, title: 'Bandra & Juhu', description: 'Explore Bandra Fort, Juhu Beach and departure.' }
    ]
  },
  {
    id: 'p7',
    title: 'Kashmir - Paradise on Earth',
    location: 'Srinagar, Kashmir',
    price: 35000,
    durationDays: 6,
    category: PackageCategory.HONEYMOON,
    rating: 4.9,
    image: 'https://picsum.photos/seed/kashmir/800/600',
    description: 'Shikara rides on Dal Lake, snow in Gulmarg, and the stunning valleys of Pahalgam.',
    featured: true,
    itinerary: [
      { day: 1, title: 'Arrival in Srinagar', description: 'Check into Houseboat and Shikara ride.' },
      { day: 2, title: 'Gulmarg Day Trip', description: 'Gondola ride and snow activities.' },
      { day: 3, title: 'Pahalgam', description: 'Visit Betaab Valley and Aru Valley.' },
      { day: 4, title: 'Sonamarg', description: 'Visit Thajiwas Glacier.' },
      { day: 5, title: 'Srinagar Sightseeing', description: 'Mughal Gardens and Shankaracharya Temple.' },
      { day: 6, title: 'Departure', description: 'Transfer to Srinagar airport.' }
    ]
  },
  {
    id: 'p8',
    title: 'Bangalore Garden City',
    location: 'Bangalore, Karnataka',
    price: 15000,
    durationDays: 3,
    category: PackageCategory.RELAXATION,
    rating: 4.4,
    image: 'https://picsum.photos/seed/bangalore/800/600',
    description: 'Enjoy the pleasant weather, craft breweries, and lush Cubbon Park.',
    itinerary: [
      { day: 1, title: 'Parks & Palaces', description: 'Lalbagh Botanical Garden and Bangalore Palace.' },
      { day: 2, title: 'Modern Bangalore', description: 'UB City, Vidhana Soudha, and Cubbon Park.' },
      { day: 3, title: 'Departure', description: 'Breakfast at MTR and airport drop.' }
    ]
  },
  {
    id: 'p9',
    title: 'Pune Cultural Escape',
    location: 'Pune, Maharashtra',
    price: 12000,
    durationDays: 2,
    category: PackageCategory.HERITAGE,
    rating: 4.3,
    image: 'https://picsum.photos/seed/pune/800/600',
    description: 'Visit the historic Shaniwar Wada and hike up Sinhagad Fort.',
    itinerary: [
      { day: 1, title: 'History of Peshwas', description: 'Shaniwar Wada and Aga Khan Palace.' },
      { day: 2, title: 'Sinhagad Fort', description: 'Morning trek and authentic Maharashtrian lunch.' }
    ]
  }
];

export const BLOG_DATA: BlogPost[] = [
  {
    id: 'b1',
    title: '10 Hidden Gems in Himachal',
    excerpt: 'Beyond Manali and Shimla, discover the untouched valleys of Tirthan and Spiti.',
    content: 'Himachal Pradesh is a treasure trove of scenic beauty, but most tourists flock to Manali and Shimla. If you want to escape the crowds, head to Tirthan Valley, the gateway to the Great Himalayan National Park. Here, you can enjoy trout fishing, river crossing, and serene hikes. \n\n Another hidden gem is Spiti Valley, a cold desert mountain valley located high in the Himalayas. The key monasteries like Key Monastery and Dhankar Monastery offer spiritual solace, while the Chandratal Lake provides breathtaking views. The rugged terrain is perfect for road trips and trekking enthusiasts looking for solitude and raw nature.',
    author: 'Amit Singh',
    date: 'Oct 12, 2023',
    category: 'Guides',
    image: 'https://picsum.photos/seed/himalaya/600/400'
  },
  {
    id: 'b2',
    title: 'The Ultimate Food Guide to Old Delhi',
    excerpt: 'From Paranthe Wali Gali to Karims, a culinary journey through history.',
    content: 'Old Delhi, or Purani Dilli, is a paradise for food lovers. Start your day with a breakfast of Bedmi Puri and Aloo Sabzi near the Fatehpuri Masjid. Then, head to Paranthe Wali Gali in Chandni Chowk for a variety of stuffed parathas served with pumpkin curry and chutney. \n\n For lunch, nothing beats the Mutton Korma and Khamiri Roti at Karims near Jama Masjid. Don’t forget to end your meal with a bowl of Shahi Tukda or Rabri Falooda at Giani’s di Hatti. The narrow lanes are bustling with history and flavors that have been preserved for generations.',
    author: 'Sarah Jenkins',
    date: 'Nov 05, 2023',
    category: 'Food',
    image: 'https://picsum.photos/seed/food/600/400'
  },
  {
    id: 'b3',
    title: 'Solo Female Travel in India',
    excerpt: 'Tips, safety advice, and the best destinations for solo female travelers.',
    content: 'Traveling solo as a woman in India can be an enriching experience if planned well. Safety is paramount, so always choose accommodation with good reviews and try to arrive at your destination before dark. Dress modestly to respect local customs, especially in rural areas and religious sites. \n\n Destinations like Udaipur, Rishikesh, and Pondicherry are known to be traveler-friendly and safe. Use public transport or registered cabs like Uber/Ola for commuting. Trust your instincts and don’t hesitate to say no if you feel uncomfortable. Connect with other travelers in hostels to make your journey more social and secure.',
    author: 'Priya K.',
    date: 'Dec 01, 2023',
    category: 'Tips',
    image: 'https://picsum.photos/seed/traveler/600/400'
  }
];