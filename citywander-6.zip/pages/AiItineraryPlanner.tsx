import React, { useState } from 'react';
import { Sparkles, Map, Calendar, Wallet, Loader2 } from 'lucide-react';
import { generateItinerary } from '../services/geminiService';

export default function AiItineraryPlanner() {
  const [formData, setFormData] = useState({
    destination: '',
    days: '3',
    interests: '',
  });
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.destination || !formData.interests) return;

    setLoading(true);
    setResult('');
    const itinerary = await generateItinerary(formData.destination, formData.days, formData.interests);
    setResult(itinerary);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-3 bg-brand-100 dark:bg-brand-900/30 text-brand-600 rounded-full mb-4">
            <Sparkles size={32} />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">AI Itinerary Planner</h1>
          <p className="text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">
            Not sure what to do? Tell our AI where you want to go, and we'll craft the perfect day-by-day plan for you.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Input Form */}
          <div className="md:col-span-1">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Trip Details</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Destination
                  </label>
                  <div className="relative">
                    <Map className="absolute left-3 top-3 text-gray-400" size={18} />
                    <input
                      type="text"
                      placeholder="e.g., Udaipur, Rajasthan"
                      className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg py-2.5 pl-10 focus:ring-2 focus:ring-brand-500 outline-none dark:text-white"
                      value={formData.destination}
                      onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Duration (Days)
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-3 text-gray-400" size={18} />
                    <input
                      type="number"
                      min="1"
                      max="15"
                      className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg py-2.5 pl-10 focus:ring-2 focus:ring-brand-500 outline-none dark:text-white"
                      value={formData.days}
                      onChange={(e) => setFormData({ ...formData, days: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Interests & Vibe
                  </label>
                  <textarea
                    placeholder="e.g., History, street food, photography, relaxed pace..."
                    className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg p-3 focus:ring-2 focus:ring-brand-500 outline-none dark:text-white h-32"
                    value={formData.interests}
                    onChange={(e) => setFormData({ ...formData, interests: e.target.value })}
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-brand-600 hover:bg-brand-500 text-white font-bold py-3 rounded-lg transition-all shadow-md hover:shadow-lg disabled:opacity-70 flex items-center justify-center"
                >
                  {loading ? (
                    <>
                      <Loader2 className="animate-spin mr-2" size={20} /> Planning...
                    </>
                  ) : (
                    'Generate Itinerary'
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Results Area */}
          <div className="md:col-span-2">
            <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700 min-h-[500px]">
              {result ? (
                <div className="prose dark:prose-invert max-w-none">
                  <h3 className="text-2xl font-bold text-brand-600 mb-4">Your Custom Itinerary for {formData.destination}</h3>
                  <div className="whitespace-pre-line text-gray-700 dark:text-gray-300 leading-relaxed">
                    {result}
                  </div>
                  <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <p className="text-sm text-gray-500 italic text-center">
                      AI-generated itinerary (prototype / simulated output)
                    </p>
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-gray-400">
                  <Map size={64} className="mb-4 opacity-20" />
                  <p className="text-lg">Your itinerary will appear here.</p>
                  <p className="text-sm">Enter your trip details to get started.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}