import React, { useState } from 'react';
import { Cloud, Sun, CloudRain, Wind, Droplets, Thermometer, Search, CloudLightning, Loader2 } from 'lucide-react';
import { getSimulatedWeather, WeatherData } from '../services/weatherService';

export default function WeatherTool() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!city.trim()) return;
    
    setLoading(true);
    const data = await getSimulatedWeather(city);
    setWeather(data);
    setLoading(false);
  };

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'sunny': return <Sun size={64} className="text-yellow-500 animate-pulse" />;
      case 'clear': return <Sun size={64} className="text-orange-400" />;
      case 'cloudy':
      case 'partly cloudy': return <Cloud size={64} className="text-gray-400" />;
      case 'rainy': return <CloudRain size={64} className="text-blue-500" />;
      case 'thunderstorm': return <CloudLightning size={64} className="text-purple-500" />;
      case 'haze': return <Wind size={64} className="text-gray-400" />;
      default: return <Cloud size={64} className="text-brand-300" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Check City Weather</h1>
          <p className="text-gray-500 dark:text-gray-400">Planning a trip? Check the forecast before you pack.</p>
        </div>

        {/* Search Box */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-8 border border-gray-100 dark:border-gray-700">
          <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3.5 text-gray-400" size={20} />
              <input 
                type="text" 
                placeholder="Enter city name (e.g. Mumbai, Manali)" 
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none dark:text-white transition-all"
              />
            </div>
            <button 
              type="submit" 
              disabled={loading}
              className="bg-brand-600 hover:bg-brand-500 text-white font-bold py-3 px-8 rounded-lg shadow-md transition-all flex items-center justify-center min-w-[140px]"
            >
              {loading ? <Loader2 className="animate-spin" size={20} /> : 'Get Weather'}
            </button>
          </form>
        </div>

        {/* Weather Result */}
        {weather && (
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden border border-gray-100 dark:border-gray-700 animate-fade-in-up">
            <div className="bg-gradient-to-r from-brand-500 to-brand-700 p-8 text-white text-center relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-20 transform rotate-12">
                    {getWeatherIcon(weather.condition)}
                </div>
                <h2 className="text-4xl font-bold mb-2 relative z-10">{weather.city}</h2>
                <p className="text-brand-100 text-xl font-medium relative z-10">{weather.condition}</p>
                <div className="mt-6 flex justify-center items-center relative z-10">
                    <span className="text-7xl font-bold tracking-tighter">{weather.temperature}°</span>
                    <span className="text-2xl mt-4 opacity-80">C</span>
                </div>
            </div>
            
            <div className="p-8 grid grid-cols-2 md:grid-cols-3 gap-6">
                <div className="flex flex-col items-center p-4 bg-gray-50 dark:bg-gray-900/50 rounded-xl transition-transform hover:scale-105">
                    <Droplets className="text-blue-500 mb-2" size={28} />
                    <span className="text-gray-500 dark:text-gray-400 text-sm font-medium">Humidity</span>
                    <span className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{weather.humidity}%</span>
                </div>
                <div className="flex flex-col items-center p-4 bg-gray-50 dark:bg-gray-900/50 rounded-xl transition-transform hover:scale-105">
                    <Wind className="text-teal-500 mb-2" size={28} />
                    <span className="text-gray-500 dark:text-gray-400 text-sm font-medium">Wind</span>
                    <span className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{weather.windSpeed} km/h</span>
                </div>
                 <div className="col-span-2 md:col-span-1 flex flex-col items-center p-4 bg-gray-50 dark:bg-gray-900/50 rounded-xl transition-transform hover:scale-105">
                    <Thermometer className="text-red-500 mb-2" size={28} />
                    <span className="text-gray-500 dark:text-gray-400 text-sm font-medium">Feels Like</span>
                    <span className="text-2xl font-bold text-gray-800 dark:text-white mt-1">{weather.temperature + 2}°</span>
                </div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-900/80 p-3 text-center border-t border-gray-100 dark:border-gray-700">
                <p className="text-xs text-gray-500 italic">Weather data shown is for demonstration purposes.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}