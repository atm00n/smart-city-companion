import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, Sparkles, Map, Car } from 'lucide-react';
import DistanceCalculator from '../components/DistanceCalculator';
import PackageCard from '../components/PackageCard';
import { PACKAGES_DATA, BLOG_DATA } from '../constants';

export default function Home() {
  const featuredPackages = PACKAGES_DATA.filter(p => p.featured);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative h-[600px] w-full overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1570125909232-eb263c188f7e?auto=format&fit=crop&w=2071&q=80" 
            alt="Cinematic bus driving through hills" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40 bg-gradient-to-t from-black/80 to-transparent"></div>
        </div>
        <div className="relative z-10 h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center text-center sm:text-left">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Discover the Soul <br/> of <span className="text-brand-400">Incredible India</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl">
            From the snow-capped Himalayas to the backwaters of Kerala. 
            Curated journeys, authentic experiences, and memories for a lifetime.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <Link to="/packages" className="px-8 py-3 bg-brand-600 hover:bg-brand-500 text-white rounded-full font-bold transition-all transform hover:scale-105">
              Explore Packages
            </Link>
            <Link to="/planner" className="px-8 py-3 bg-white/20 backdrop-blur-md hover:bg-white/30 text-white border border-white/50 rounded-full font-bold transition-all flex items-center justify-center">
              <Sparkles size={18} className="mr-2" /> Plan with AI
            </Link>
          </div>
        </div>
      </div>

      <DistanceCalculator />

      {/* Featured Destinations */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-12">
          <div>
            <span className="text-brand-600 font-bold tracking-wider uppercase text-sm">Trending Now</span>
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mt-2">Popular Packages</h2>
          </div>
          <Link to="/packages" className="hidden md:flex items-center text-brand-600 font-semibold hover:text-brand-700">
            View All <ArrowRight size={18} className="ml-2" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredPackages.map(pkg => (
            <PackageCard key={pkg.id} pkg={pkg} />
          ))}
        </div>
        
        <div className="mt-8 text-center md:hidden">
            <Link to="/packages" className="inline-flex items-center text-brand-600 font-semibold">
                View All <ArrowRight size={18} className="ml-2" />
            </Link>
        </div>
      </section>

      {/* Car Rental Promo Section */}
      <section className="bg-white dark:bg-gray-950 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-3xl overflow-hidden shadow-2xl relative">
                <div className="absolute inset-0">
                    <img src="https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=2021&q=80" alt="Road trip" className="w-full h-full object-cover opacity-40" />
                </div>
                <div className="relative z-10 p-10 md:p-16 flex flex-col md:flex-row items-center justify-between">
                    <div className="md:w-3/5 mb-8 md:mb-0">
                        <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Drive Your Own Adventure</h2>
                        <p className="text-gray-300 text-lg mb-8 max-w-lg">
                            Explore the city at your own pace. Choose from our wide range of premium hatchbacks, sedans, and SUVs. Affordable rates, unlimited kilometers.
                        </p>
                        <Link to="/cars" className="inline-flex items-center bg-brand-600 hover:bg-brand-500 text-white px-8 py-4 rounded-full font-bold transition-all shadow-lg transform hover:scale-105">
                             Book a Car <ArrowRight size={20} className="ml-2" />
                        </Link>
                    </div>
                     <div className="md:w-2/5 flex justify-center">
                        <div className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500">
                             <div className="flex items-center space-x-4 mb-4 text-white">
                                <div className="bg-brand-500 p-3 rounded-full">
                                    <Car size={24} />
                                </div>
                                <div>
                                    <div className="font-bold text-lg">Self Drive Rentals</div>
                                    <div className="text-sm text-gray-300">Starts @ ₹1500/day</div>
                                </div>
                             </div>
                             <div className="space-y-2 text-sm text-gray-200">
                                 <div className="flex items-center"><CheckCircle size={16} className="text-brand-400 mr-2" /> No Hidden Charges</div>
                                 <div className="flex items-center"><CheckCircle size={16} className="text-brand-400 mr-2" /> 24/7 Roadside Assist</div>
                                 <div className="flex items-center"><CheckCircle size={16} className="text-brand-400 mr-2" /> Clean & Sanitized</div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>

      {/* AI Planner Promo Section */}
      <section className="bg-gradient-to-r from-indigo-900 to-brand-900 py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -mr-16 -mt-16"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -ml-16 -mb-16"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="flex flex-col md:flex-row items-center justify-between">
                <div className="md:w-1/2 mb-10 md:mb-0">
                    <div className="inline-block bg-white/10 text-brand-200 px-4 py-1 rounded-full text-sm font-semibold mb-6">
                        <span className="flex items-center"><Sparkles size={16} className="mr-2" /> New Feature</span>
                    </div>
                    <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Create Your Perfect Itinerary in Seconds</h2>
                    <p className="text-indigo-100 text-lg mb-8 max-w-lg">
                        Unsure where to go? Tell our smart AI about your interests, duration, and vibe, and get a personalized day-by-day travel plan instantly.
                    </p>
                    <Link to="/planner" className="inline-flex items-center bg-white text-brand-900 px-8 py-4 rounded-full font-bold hover:bg-brand-50 transition-colors shadow-lg">
                        Try AI Planner <ArrowRight size={20} className="ml-2" />
                    </Link>
                </div>
                <div className="md:w-5/12">
                    <div className="bg-white/10 backdrop-blur-lg p-6 rounded-2xl border border-white/20 shadow-2xl transform rotate-3">
                        <div className="flex items-center space-x-3 mb-4 border-b border-white/10 pb-4">
                            <Map className="text-brand-300" />
                            <span className="text-white font-bold">Your Custom Plan</span>
                        </div>
                        <div className="space-y-3">
                            <div className="h-2 bg-white/20 rounded w-3/4"></div>
                            <div className="h-2 bg-white/10 rounded w-full"></div>
                            <div className="h-2 bg-white/10 rounded w-5/6"></div>
                            <div className="h-2 bg-white/10 rounded w-4/5"></div>
                        </div>
                        <div className="mt-6 flex justify-between items-center">
                             <div className="text-brand-200 text-sm">Generating...</div>
                             <div className="w-8 h-8 rounded-full border-2 border-brand-300 border-t-transparent animate-spin"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="bg-brand-50 dark:bg-gray-900 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
                <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Why Travel with cityWander?</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                {[
                    { title: 'Handpicked Hotels', desc: 'We only partner with top-rated hotels ensuring comfort & luxury.' },
                    { title: 'Best Price Guarantee', desc: 'We match any comparable price you find elsewhere.' },
                    { title: '24/7 Support', desc: 'Our team is always available to help you during your trip.' }
                ].map((item, idx) => (
                    <div key={idx} className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-sm text-center">
                        <div className="mx-auto w-12 h-12 bg-brand-100 dark:bg-brand-900/30 text-brand-600 rounded-full flex items-center justify-center mb-6">
                            <CheckCircle size={24} />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">{item.title}</h3>
                        <p className="text-gray-500 dark:text-gray-400">{item.desc}</p>
                    </div>
                ))}
            </div>
        </div>
      </section>

      {/* Latest Blog */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-12">Travel Stories</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {BLOG_DATA.map(post => (
                <Link to={`/blog/${post.id}`} key={post.id} className="group cursor-pointer">
                    <div className="relative h-64 overflow-hidden rounded-xl mb-4">
                        <img src={post.image} alt={post.title} className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500" />
                        <div className="absolute top-4 left-4 bg-white/90 dark:bg-gray-900/90 px-3 py-1 rounded-full text-xs font-bold text-brand-600 uppercase">
                            {post.category}
                        </div>
                    </div>
                    <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 mb-2 space-x-2">
                        <span>{post.date}</span>
                        <span>•</span>
                        <span>{post.author}</span>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white group-hover:text-brand-600 transition-colors">
                        {post.title}
                    </h3>
                    <p className="text-gray-500 dark:text-gray-400 mt-2 line-clamp-2">
                        {post.excerpt}
                    </p>
                </Link>
            ))}
        </div>
      </section>

      {/* Slogan / Ending Section */}
      <section className="bg-gray-900 text-white py-24 text-center px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/stars/1920/1080')] opacity-10 bg-cover bg-center"></div>
        <div className="relative z-10 max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-5xl font-serif italic mb-8">
                "Travel is the only thing you buy that makes you richer."
            </h2>
            <div className="w-24 h-1 bg-brand-500 mx-auto mb-8"></div>
            <p className="text-gray-400 text-lg mb-10">
                Let us help you write your next chapter. The world is waiting.
            </p>
            <Link to="/packages" className="inline-block bg-brand-600 hover:bg-brand-500 text-white font-bold py-4 px-10 rounded-full transition-transform hover:scale-105">
                Start Your Journey
            </Link>
        </div>
      </section>
    </div>
  );
}