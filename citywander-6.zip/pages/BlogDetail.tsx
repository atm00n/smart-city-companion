import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, User, Tag } from 'lucide-react';
import { BLOG_DATA } from '../constants';

export default function BlogDetail() {
  const { id } = useParams<{ id: string }>();
  const post = BLOG_DATA.find(p => p.id === id);

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-950">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Post not found</h2>
          <Link to="/blog" className="text-brand-600 hover:underline">Back to Blog</Link>
        </div>
      </div>
    );
  }

  return (
    <article className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-20">
      {/* Hero Image */}
      <div className="relative h-[400px] w-full">
        <img 
          src={post.image} 
          alt={post.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="absolute bottom-0 left-0 w-full p-8 bg-gradient-to-t from-black/80 to-transparent">
            <div className="max-w-4xl mx-auto text-white">
                <Link to="/blog" className="inline-flex items-center text-white/80 hover:text-white mb-6 transition-colors">
                    <ArrowLeft size={20} className="mr-2" /> Back to Blog
                </Link>
                <div className="flex items-center space-x-2 mb-4">
                     <span className="bg-brand-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">{post.category}</span>
                </div>
                <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">{post.title}</h1>
                <div className="flex items-center space-x-6 text-sm md:text-base text-gray-200">
                    <span className="flex items-center"><User size={18} className="mr-2" /> {post.author}</span>
                    <span className="flex items-center"><Calendar size={18} className="mr-2" /> {post.date}</span>
                </div>
            </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 relative z-10">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 md:p-12 shadow-xl border border-gray-100 dark:border-gray-700">
            <div className="prose dark:prose-invert max-w-none">
                <p className="text-xl text-gray-600 dark:text-gray-300 font-medium mb-8 border-l-4 border-brand-500 pl-4 italic">
                    {post.excerpt}
                </p>
                <div className="text-gray-800 dark:text-gray-200 leading-relaxed whitespace-pre-line">
                    {post.content || post.excerpt}
                </div>
            </div>
            
            <div className="mt-12 pt-8 border-t border-gray-100 dark:border-gray-700 flex justify-between items-center">
                <div className="text-gray-500 dark:text-gray-400 text-sm">
                    Share this story
                </div>
                <div className="flex space-x-4">
                    {/* Social share placeholders */}
                    <button className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 flex items-center justify-center hover:bg-blue-200 transition-colors">
                        <span className="sr-only">Facebook</span>
                        F
                    </button>
                    <button className="w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-900/30 text-sky-500 flex items-center justify-center hover:bg-sky-200 transition-colors">
                        <span className="sr-only">Twitter</span>
                        T
                    </button>
                </div>
            </div>
        </div>
      </div>
    </article>
  );
}