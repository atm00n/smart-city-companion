import React, { useState } from 'react';
import { Car, Calendar, MapPin, Fuel, Users, Gauge, Check, Search, Star, X, Info } from 'lucide-react';
import { CAR_CITIES, MOCK_CARS, Car as CarType } from '../services/carData';

export default function CarRental() {
  const [formData, setFormData] = useState({
    city: '',
    pickupDate: '',
    dropoffDate: '',
    carType: 'All'
  });
  
  const [results, setResults] = useState<CarType[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [selectedCar, setSelectedCar] = useState<CarType | null>(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
    setBookingConfirmed(false);
    setSelectedCar(null);

    // Filter logic
    let filtered = MOCK_CARS;
    if (formData.carType !== 'All') {
        filtered = filtered.filter(c => c.type === formData.carType);
    }
    setResults(filtered);
  };

  const calculateDays = () => {
    if (!formData.pickupDate || !formData.dropoffDate) return 0;
    const start = new Date(formData.pickupDate);
    const end = new Date(formData.dropoffDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
    return diffDays || 1; // Minimum 1 day
  };

  const totalDays = calculateDays();

  const handleBookClick = (car: CarType) => {
    setSelectedCar(car);
    setBookingConfirmed(false);
  };

  const confirmBooking = () => {
    setBookingConfirmed(true);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-20">
      {/* Hero Section */}
      <div className="bg-brand-900 py-16 px-4 sm:px-6 lg:px-8 text-center text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&w=1600&q=80')] bg-cover bg-center opacity-20"></div>
        <div className="relative z-10 max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Rent the Perfect Car</h1>
            <p className="text-xl text-brand-100">Self-drive rentals for your city wanderlust. No hidden charges.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 relative z-20">
        {/* Search Form */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700">
            <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">City</label>
                    <div className="relative">
                        <MapPin className="absolute left-3 top-3 text-gray-400" size={18} />
                        <select 
                            required
                            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg outline-none focus:ring-2 focus:ring-brand-500 dark:text-white"
                            value={formData.city}
                            onChange={e => setFormData({...formData, city: e.target.value})}
                        >
                            <option value="">Select City</option>
                            {CAR_CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                </div>
                <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Pickup Date</label>
                    <div className="relative">
                        <Calendar className="absolute left-3 top-3 text-gray-400" size={18} />
                        <input 
                            required
                            type="date" 
                            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg outline-none focus:ring-2 focus:ring-brand-500 dark:text-white"
                            value={formData.pickupDate}
                            onChange={e => setFormData({...formData, pickupDate: e.target.value})}
                        />
                    </div>
                </div>
                <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Dropoff Date</label>
                    <div className="relative">
                        <Calendar className="absolute left-3 top-3 text-gray-400" size={18} />
                        <input 
                            required
                            type="date" 
                            min={formData.pickupDate}
                            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg outline-none focus:ring-2 focus:ring-brand-500 dark:text-white"
                            value={formData.dropoffDate}
                            onChange={e => setFormData({...formData, dropoffDate: e.target.value})}
                        />
                    </div>
                </div>
                <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Car Type</label>
                    <div className="relative">
                        <Car className="absolute left-3 top-3 text-gray-400" size={18} />
                        <select 
                            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg outline-none focus:ring-2 focus:ring-brand-500 dark:text-white"
                            value={formData.carType}
                            onChange={e => setFormData({...formData, carType: e.target.value})}
                        >
                            <option value="All">All Types</option>
                            <option value="Hatchback">Hatchback</option>
                            <option value="Sedan">Sedan</option>
                            <option value="SUV">SUV</option>
                            <option value="Luxury">Luxury</option>
                        </select>
                    </div>
                </div>
                <div className="flex items-end">
                    <button type="submit" className="w-full bg-brand-600 hover:bg-brand-500 text-white font-bold py-3 rounded-lg shadow-md transition-colors flex justify-center items-center">
                        <Search size={20} className="mr-2" /> Find Cars
                    </button>
                </div>
            </form>
        </div>

        {/* Results */}
        <div className="mt-12">
            {!hasSearched ? (
                <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                    <Car size={64} className="mx-auto mb-4 opacity-20" />
                    <p className="text-xl">Enter your trip details to see available cars.</p>
                </div>
            ) : results.length === 0 ? (
                <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                    <p className="text-xl">No cars available for the selected criteria.</p>
                </div>
            ) : (
                <>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Available Cars in {formData.city}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {results.map(car => (
                        <div key={car.id} className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-lg border border-gray-100 dark:border-gray-700 hover:shadow-xl transition-shadow group">
                            <div className="relative h-48 bg-gray-100 dark:bg-gray-700">
                                <img 
                                    src={car.image} 
                                    alt={car.name} 
                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                                />
                                <div className="absolute top-3 right-3 bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm px-2 py-1 rounded-md text-xs font-bold text-gray-900 dark:text-white flex items-center shadow-sm">
                                    <Star size={12} className="text-yellow-400 fill-current mr-1" /> {car.rating}
                                </div>
                            </div>
                            <div className="p-6">
                                <div className="flex justify-between items-start mb-2">
                                    <div>
                                        <h3 className="text-lg font-bold text-gray-900 dark:text-white">{car.name}</h3>
                                        <span className="text-xs text-gray-500 dark:text-gray-400">{car.type}</span>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-xl font-bold text-brand-600 dark:text-brand-400">₹{car.pricePerDay}</p>
                                        <p className="text-xs text-gray-500">/ day</p>
                                    </div>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-4 my-4">
                                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                                        <Users size={16} className="mr-2 text-brand-500" /> {car.seats} Seats
                                    </div>
                                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                                        <Fuel size={16} className="mr-2 text-brand-500" /> {car.fuel}
                                    </div>
                                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                                        <Gauge size={16} className="mr-2 text-brand-500" /> {car.transmission}
                                    </div>
                                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                                        <MapPin size={16} className="mr-2 text-brand-500" /> GPS
                                    </div>
                                </div>

                                <button 
                                    onClick={() => handleBookClick(car)}
                                    className="w-full block text-center bg-gray-900 dark:bg-white text-white dark:text-gray-900 py-3 rounded-lg font-bold hover:bg-brand-600 dark:hover:bg-gray-200 transition-colors"
                                >
                                    Book Now
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
                </>
            )}
        </div>

        <div className="mt-12 text-center">
            <p className="text-sm text-gray-400 italic">Car rental options shown are for demonstration purposes only.</p>
        </div>
      </div>

      {/* Booking Modal */}
      {selectedCar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden animate-fade-in-up">
                {bookingConfirmed ? (
                    <div className="p-8 text-center">
                        <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Check size={32} />
                        </div>
                        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Booking Confirmed!</h2>
                        <p className="text-gray-600 dark:text-gray-300 mb-6">
                            Your <span className="font-semibold">{selectedCar.name}</span> is reserved for {formData.city}.<br/>
                            We sent the details to your email.
                        </p>
                        <button 
                            onClick={() => setSelectedCar(null)}
                            className="bg-brand-600 hover:bg-brand-500 text-white font-bold py-2 px-6 rounded-lg transition-colors"
                        >
                            Close
                        </button>
                    </div>
                ) : (
                    <>
                        <div className="bg-gray-50 dark:bg-gray-700/50 p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white">Confirm Booking</h3>
                            <button onClick={() => setSelectedCar(null)} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                                <X size={24} />
                            </button>
                        </div>
                        <div className="p-6 space-y-4">
                            <div className="flex items-center space-x-4">
                                <img src={selectedCar.image} alt={selectedCar.name} className="w-20 h-16 object-cover rounded-lg bg-gray-100 dark:bg-gray-700" />
                                <div>
                                    <h4 className="font-bold text-gray-900 dark:text-white">{selectedCar.name}</h4>
                                    <p className="text-sm text-gray-500">{selectedCar.type} • {selectedCar.fuel}</p>
                                </div>
                            </div>
                            
                            <div className="bg-brand-50 dark:bg-brand-900/20 p-4 rounded-lg space-y-2 text-sm">
                                <div className="flex justify-between">
                                    <span className="text-gray-600 dark:text-gray-300">Pickup</span>
                                    <span className="font-semibold text-gray-900 dark:text-white">{formData.pickupDate}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-gray-600 dark:text-gray-300">Dropoff</span>
                                    <span className="font-semibold text-gray-900 dark:text-white">{formData.dropoffDate}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-gray-600 dark:text-gray-300">Duration</span>
                                    <span className="font-semibold text-gray-900 dark:text-white">{totalDays} Days</span>
                                </div>
                                <div className="border-t border-brand-200 dark:border-brand-800 pt-2 flex justify-between items-center mt-2">
                                    <span className="text-brand-800 dark:text-brand-300 font-bold">Total Amount</span>
                                    <span className="text-xl font-bold text-brand-600 dark:text-brand-400">₹{(selectedCar.pricePerDay * totalDays).toLocaleString()}</span>
                                </div>
                            </div>

                            <div className="flex items-start space-x-2 text-xs text-gray-500 bg-gray-50 dark:bg-gray-900 p-3 rounded-lg">
                                <Info size={16} className="flex-shrink-0 mt-0.5" />
                                <p>You will need to present a valid Driving License and ID proof at the time of pickup. Security deposit may apply.</p>
                            </div>

                            <button 
                                onClick={confirmBooking}
                                className="w-full bg-brand-600 hover:bg-brand-500 text-white font-bold py-3 rounded-lg shadow-md transition-all hover:shadow-lg"
                            >
                                Confirm & Pay at Counter
                            </button>
                        </div>
                    </>
                )}
            </div>
        </div>
      )}
    </div>
  );
}