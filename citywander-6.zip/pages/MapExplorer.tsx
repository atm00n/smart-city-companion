import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { Map, MapPin, Navigation } from 'lucide-react';
import { MAP_DATA, CityData } from '../services/mapData';
import { useTheme } from '../context/ThemeContext';

export default function MapExplorer() {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.LayerGroup | null>(null);
  const { isDark } = useTheme();
  
  const [selectedCity, setSelectedCity] = useState<CityData>(MAP_DATA[0]);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Create map instance if it doesn't exist
    if (!mapInstanceRef.current) {
        mapInstanceRef.current = L.map(mapContainerRef.current).setView(
            [selectedCity.center.lat, selectedCity.center.lng], 
            selectedCity.zoom
        );

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(mapInstanceRef.current);

        markersRef.current = L.layerGroup().addTo(mapInstanceRef.current);
    }

    // Cleanup on unmount
    return () => {
        if (mapInstanceRef.current) {
            mapInstanceRef.current.remove();
            mapInstanceRef.current = null;
        }
    };
  }, []);

  // Handle City Change
  useEffect(() => {
    const map = mapInstanceRef.current;
    const markers = markersRef.current;

    if (map && markers) {
        // Fly to new city
        map.flyTo([selectedCity.center.lat, selectedCity.center.lng], selectedCity.zoom, {
            duration: 1.5
        });

        // Clear old markers
        markers.clearLayers();

        // Add new markers
        selectedCity.attractions.forEach(attraction => {
            // Custom Icon
            const customIcon = L.divIcon({
                className: 'custom-div-icon',
                html: `<div style="background-color: #0ea5e9; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 4px 6px rgba(0,0,0,0.3);"></div>`,
                iconSize: [24, 24],
                iconAnchor: [12, 12],
                popupAnchor: [0, -12]
            });

            const marker = L.marker([attraction.location.lat, attraction.location.lng], { icon: customIcon })
                .bindPopup(`
                    <div style="font-family: Inter, sans-serif; min-width: 200px;">
                        <h3 style="font-weight: bold; font-size: 16px; margin-bottom: 4px; color: #0f172a;">${attraction.name}</h3>
                        <p style="font-size: 13px; color: #475569; margin: 0;">${attraction.description}</p>
                    </div>
                `);
            
            markers.addLayer(marker);
        });
    }
  }, [selectedCity]);

  // Force resize to fix tile loading issues if container size changes
  useEffect(() => {
    setTimeout(() => {
        mapInstanceRef.current?.invalidateSize();
    }, 100);
  }, [selectedCity]);

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-white dark:bg-gray-950">
      
      {/* Sidebar / Controls */}
      <div className="w-full md:w-80 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 flex flex-col z-20 shadow-lg">
        <div className="p-6 border-b border-gray-200 dark:border-gray-800">
            <div className="flex items-center space-x-2 text-brand-600 mb-2">
                <Map size={24} />
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">Map Explorer</h1>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Select a city to explore top attractions.</p>
        </div>

        <div className="p-6 flex-1 overflow-y-auto">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Select Destination</h2>
            <div className="space-y-2">
                {MAP_DATA.map(city => (
                    <button
                        key={city.id}
                        onClick={() => setSelectedCity(city)}
                        className={`w-full text-left px-4 py-3 rounded-lg flex items-center justify-between transition-all ${
                            selectedCity.id === city.id 
                            ? 'bg-brand-50 dark:bg-brand-900/20 text-brand-700 dark:text-brand-300 ring-1 ring-brand-200 dark:ring-brand-800' 
                            : 'hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300'
                        }`}
                    >
                        <span className="font-medium">{city.name}</span>
                        {selectedCity.id === city.id && <Navigation size={16} />}
                    </button>
                ))}
            </div>

            <div className="mt-8">
                <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Highlights</h2>
                <div className="space-y-3">
                    {selectedCity.attractions.map((attr, idx) => (
                        <div key={idx} className="flex items-start space-x-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg border border-gray-100 dark:border-gray-700/50">
                            <MapPin size={16} className="text-brand-500 mt-1 flex-shrink-0" />
                            <div>
                                <h3 className="text-sm font-semibold text-gray-900 dark:text-white">{attr.name}</h3>
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">{attr.description}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      </div>

      {/* Map Area */}
      <div className="flex-1 relative h-[60vh] md:h-screen">
        <div 
            id="map" 
            ref={mapContainerRef} 
            className="w-full h-full bg-gray-100 z-10"
        />
        
        {/* Overlay Note */}
        <div className="absolute bottom-0 right-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm px-4 py-2 text-xs text-gray-500 dark:text-gray-400 z-[400] rounded-tl-lg pointer-events-none">
            Map data © OpenStreetMap contributors. For demonstration purposes.
        </div>

        {/* Mobile-only instruction overlay if needed */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-white dark:bg-gray-800 px-4 py-2 rounded-full shadow-lg z-[400] md:hidden flex items-center space-x-2">
            <span className="w-2 h-2 bg-brand-500 rounded-full animate-pulse"></span>
            <span className="text-xs font-bold text-gray-700 dark:text-white">{selectedCity.name}</span>
        </div>
      </div>
    </div>
  );
}