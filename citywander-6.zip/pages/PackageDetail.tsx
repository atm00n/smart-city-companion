import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Clock, MapPin, Calendar, Check, Star, ArrowLeft, Loader2 } from 'lucide-react';
import { PACKAGES_DATA } from '../constants';
import { useApp } from '../context/AppContext';

export default function PackageDetail() {
  const { id } = useParams<{ id: string }>();
  const { addBooking } = useApp();
  const pkg = PACKAGES_DATA.find(p => p.id === id);
  const [booked, setBooked] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', date: '' });

  if (!pkg) return <div className="p-20 text-center text-gray-500">Package not found</div>;

  const handleBook = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    
    try {
        const response = await fetch("https://formspree.io/f/xgowabvr", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                _subject: `New Booking: ${pkg.title}`,
                package: pkg.title,
                packageId: pkg.id,
                ...formData
            })
        });
        
        if (response.ok) {
            // Update local state for immediate UI feedback and admin demo
            addBooking({
                id: Date.now().toString(),
                packageId: pkg.id,
                customerName: formData.name,
                email: formData.email,
                date: formData.date,
                status: 'Pending'
            });
            setBooked(true);
        } else {
            alert("There was a problem submitting your booking. Please try again.");
        }
    } catch (error) {
        console.error("Error submitting form:", error);
        alert("Network error. Please try again.");
    } finally {
        setSubmitting(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-950 min-h-screen pb-20">
      {/* Header Image */}
      <div className="relative h-[400px]">
        <img src={pkg.image} alt={pkg.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="absolute bottom-0 left-0 w-full p-8 bg-gradient-to-t from-black/80 to-transparent">
            <div className="max-w-7xl mx-auto">
                <Link to="/packages" className="text-white/80 hover:text-white flex items-center mb-4">
                    <ArrowLeft size={20} className="mr-2" /> Back to Packages
                </Link>
                <div className="flex flex-col md:flex-row justify-between items-end">
                    <div>
                        <span className="bg-brand-600 text-white px-3 py-1 rounded-md text-sm font-bold mb-3 inline-block">
                            {pkg.category}
                        </span>
                        <h1 className="text-4xl font-bold text-white mb-2">{pkg.title}</h1>
                        <div className="flex items-center text-white/90 space-x-4 text-sm">
                            <span className="flex items-center"><MapPin size={16} className="mr-1"/> {pkg.location}</span>
                            <span className="flex items-center"><Clock size={16} className="mr-1"/> {pkg.durationDays} Days</span>
                            <span className="flex items-center text-yellow-400"><Star size={16} className="mr-1 fill-current"/> {pkg.rating}</span>
                        </div>
                    </div>
                    <div className="text-white text-right mt-4 md:mt-0">
                        <p className="text-sm opacity-80">Price per person</p>
                        <p className="text-3xl font-bold">₹{pkg.price.toLocaleString()}</p>
                    </div>
                </div>
            </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-12">
            <section>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Overview</h2>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{pkg.description}</p>
            </section>

            <section>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Itinerary</h2>
                <div className="border-l-2 border-brand-200 dark:border-brand-900 ml-3 space-y-8">
                    {pkg.itinerary.map((day) => (
                        <div key={day.day} className="relative pl-8">
                            <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-brand-500 border-4 border-white dark:border-gray-950"></div>
                            <h3 className="text-lg font-bold text-gray-900 dark:text-white">Day {day.day}: {day.title}</h3>
                            <p className="text-gray-600 dark:text-gray-400 mt-2">{day.description}</p>
                        </div>
                    ))}
                </div>
            </section>

            <section>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">What's Included</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {['Accommodation', 'Breakfast & Dinner', 'Sightseeing Transfers', 'Guide', 'All Taxes'].map(item => (
                        <div key={item} className="flex items-center text-gray-700 dark:text-gray-300">
                            <Check size={18} className="text-green-500 mr-2" /> {item}
                        </div>
                    ))}
                </div>
            </section>
        </div>

        {/* Booking Sidebar */}
        <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700 sticky top-24">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Book This Package</h3>
                {booked ? (
                    <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-6 text-center">
                        <div className="w-12 h-12 bg-green-100 dark:bg-green-800 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Check className="text-green-600 dark:text-green-300" />
                        </div>
                        <h4 className="text-green-800 dark:text-green-200 font-bold text-lg mb-2">Booking Requested!</h4>
                        <p className="text-green-700 dark:text-green-300 text-sm">We will contact you shortly to confirm your trip.</p>
                        <button onClick={() => setBooked(false)} className="mt-4 text-sm text-green-700 underline">Book another</button>
                    </div>
                ) : (
                    <form onSubmit={handleBook} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Full Name</label>
                            <input required name="name" type="text" className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg p-2.5 dark:text-white"
                                value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email Address</label>
                            <input required name="email" type="email" className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg p-2.5 dark:text-white"
                                value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Travel Date</label>
                            <div className="relative">
                                <Calendar size={18} className="absolute left-3 top-3 text-gray-400" />
                                <input required name="date" type="date" className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg p-2.5 pl-10 dark:text-white"
                                    value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})}
                                />
                            </div>
                        </div>
                        <div className="pt-4">
                            <button type="submit" disabled={submitting} className="w-full bg-brand-600 hover:bg-brand-500 text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center">
                                {submitting ? <Loader2 className="animate-spin mr-2" /> : null}
                                {submitting ? 'Sending...' : 'Send Inquiry'}
                            </button>
                            <p className="text-xs text-center text-gray-500 mt-2">No payment required today.</p>
                        </div>
                    </form>
                )}
            </div>
        </div>
      </div>
    </div>
  );
}