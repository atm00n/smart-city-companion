import React, { useState } from 'react';
import { Filter, X } from 'lucide-react';
import PackageCard from '../components/PackageCard';
import { PACKAGES_DATA } from '../constants';
import { PackageCategory } from '../types';

export default function Packages() {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [maxPrice, setMaxPrice] = useState<number>(50000);
  const [showFilters, setShowFilters] = useState(false);

  const filteredPackages = PACKAGES_DATA.filter(pkg => {
    const categoryMatch = selectedCategory === 'All' || pkg.category === selectedCategory;
    const priceMatch = pkg.price <= maxPrice;
    return categoryMatch && priceMatch;
  });

  const categories = ['All', ...Object.values(PackageCategory)];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pt-8 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Explore Packages</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-2">Find your perfect getaway from {filteredPackages.length} options.</p>
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className="mt-4 md:mt-0 flex items-center bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-700 dark:text-white md:hidden"
          >
            <Filter size={16} className="mr-2" /> Filters
          </button>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className={`w-full md:w-64 flex-shrink-0 ${showFilters ? 'block' : 'hidden md:block'}`}>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-xl border border-gray-200 dark:border-gray-700 sticky top-24">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-lg dark:text-white">Filters</h3>
                <button onClick={() => setShowFilters(false)} className="md:hidden text-gray-500">
                    <X size={20} />
                </button>
              </div>
              
              <div className="mb-8">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Category</label>
                <div className="space-y-2">
                  {categories.map(cat => (
                    <label key={cat} className="flex items-center cursor-pointer">
                      <input 
                        type="radio" 
                        name="category" 
                        className="form-radio text-brand-600 focus:ring-brand-500"
                        checked={selectedCategory === cat}
                        onChange={() => setSelectedCategory(cat)}
                      />
                      <span className="ml-2 text-sm text-gray-600 dark:text-gray-400">{cat}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                    Max Price: <span className="text-brand-600">₹{maxPrice.toLocaleString()}</span>
                </label>
                <input 
                  type="range" 
                  min="5000" 
                  max="50000" 
                  step="1000" 
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-brand-600"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-2">
                    <span>₹5k</span>
                    <span>₹50k+</span>
                </div>
              </div>
            </div>
          </div>

          {/* Package Grid */}
          <div className="flex-1">
            {filteredPackages.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPackages.map(pkg => (
                    <PackageCard key={pkg.id} pkg={pkg} />
                ))}
                </div>
            ) : (
                <div className="text-center py-20">
                    <p className="text-xl text-gray-500">No packages found matching your criteria.</p>
                    <button 
                        onClick={() => { setSelectedCategory('All'); setMaxPrice(50000); }}
                        className="mt-4 text-brand-600 font-semibold hover:underline"
                    >
                        Clear Filters
                    </button>
                </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}