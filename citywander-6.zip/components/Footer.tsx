import React from 'react';
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <MapPin className="text-brand-500" />
              <span className="text-xl font-bold text-white">cityWander</span>
            </div>
            <p className="text-sm text-gray-400">
              Discover the soul of India with our curated travel experiences. 
              From the Himalayas to the Indian Ocean, we guide you everywhere.
            </p>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="/" className="hover:text-brand-400">Home</a></li>
              <li><a href="/#/packages" className="hover:text-brand-400">Packages</a></li>
              <li><a href="/#/blog" className="hover:text-brand-400">Travel Blog</a></li>
              <li><a href="#" className="hover:text-brand-400">About Us</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Contact</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center"><Phone size={16} className="mr-2" /> +91 98765 43210</li>
              <li className="flex items-center"><Mail size={16} className="mr-2" /> hello@citywander.in</li>
              <li className="flex items-center"><MapPin size={16} className="mr-2" /> CP, New Delhi, India</li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-brand-400"><Facebook size={20} /></a>
              <a href="#" className="hover:text-brand-400"><Twitter size={20} /></a>
              <a href="#" className="hover:text-brand-400"><Instagram size={20} /></a>
            </div>
            <div className="mt-4">
                <p className="text-xs text-gray-500">Subscribe to newsletter</p>
                <form action="https://formspree.io/f/xgowabvr" method="POST" className="flex mt-2">
                    <input name="email" type="email" placeholder="Email" required className="bg-gray-800 border border-gray-700 text-white text-xs p-2 rounded-l-md w-full focus:outline-none focus:border-brand-500" />
                    <button type="submit" className="bg-brand-600 hover:bg-brand-500 text-white px-3 py-2 rounded-r-md text-xs">Go</button>
                </form>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-sm text-gray-500">
          © {new Date().getFullYear()} cityWander. All rights reserved.
        </div>
      </div>
    </footer>
  );
}