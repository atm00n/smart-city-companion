import React, { useState } from 'react';
import { ArrowRight, Plane, Train, Bus, Car } from 'lucide-react';

export default function DistanceCalculator() {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [result, setResult] = useState<any>(null);

  const calculate = (e: React.FormEvent) => {
    e.preventDefault();
    if(!from || !to) return;
    
    // Mock logic for demo purposes
    const dist = Math.floor(Math.random() * (2500 - 200) + 200);
    setResult({
      distance: dist,
      flight: { time: `${Math.floor(dist/500) + 1}h`, cost: `₹${dist * 5}` },
      train: { time: `${Math.floor(dist/60)}h`, cost: `₹${dist * 1.5}` },
      bus: { time: `${Math.floor(dist/40)}h`, cost: `₹${dist * 1}` },
      car: { time: `${Math.floor(dist/50)}h`, cost: `₹${dist * 3}` },
    });
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-xl -mt-16 relative z-10 mx-4 lg:mx-auto max-w-4xl border border-gray-100 dark:border-gray-700">
      <h2 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">Plan Your Journey</h2>
      <form onSubmit={calculate} className="grid grid-cols-1 md:grid-cols-7 gap-4 items-end">
        <div className="md:col-span-2">
          <label className="block text-xs font-medium text-gray-500 mb-1">From</label>
          <input 
            type="text" 
            placeholder="City (e.g. Delhi)" 
            value={from}
            onChange={e => setFrom(e.target.value)}
            className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-3 focus:ring-2 focus:ring-brand-500 outline-none dark:text-white"
          />
        </div>
        <div className="hidden md:flex justify-center items-center pb-3 text-gray-400">
            <ArrowRight />
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs font-medium text-gray-500 mb-1">To</label>
          <input 
            type="text" 
            placeholder="City (e.g. Jaipur)" 
            value={to}
            onChange={e => setTo(e.target.value)}
            className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-3 focus:ring-2 focus:ring-brand-500 outline-none dark:text-white"
          />
        </div>
        <div className="md:col-span-2">
          <button type="submit" className="w-full bg-brand-600 hover:bg-brand-500 text-white font-bold py-3 px-4 rounded-lg transition-colors">
            Check Options
          </button>
        </div>
      </form>

      {result && (
        <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 animate-fade-in">
          <p className="text-center text-gray-600 dark:text-gray-300 mb-4">
            Distance: <span className="font-bold text-brand-600">{result.distance} km</span>
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { mode: 'Flight', icon: Plane, data: result.flight },
              { mode: 'Train', icon: Train, data: result.train },
              { mode: 'Bus', icon: Bus, data: result.bus },
              { mode: 'Car', icon: Car, data: result.car },
            ].map((item) => (
              <div key={item.mode} className="flex flex-col items-center p-3 rounded-lg bg-gray-50 dark:bg-gray-700/50">
                <item.icon size={24} className="text-brand-500 mb-2" />
                <span className="font-semibold text-gray-800 dark:text-white">{item.mode}</span>
                <span className="text-xs text-gray-500 dark:text-gray-400">{item.data.time}</span>
                <span className="text-sm font-bold text-brand-600 mt-1">{item.data.cost}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}