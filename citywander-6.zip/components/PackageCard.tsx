import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Star, Heart } from 'lucide-react';
import { TravelPackage } from '../types';
import { useApp } from '../context/AppContext';

interface Props {
  pkg: TravelPackage;
}

const PackageCard: React.FC<Props> = ({ pkg }) => {
  const { bookmarks, toggleBookmark } = useApp();
  const isBookmarked = bookmarks.includes(pkg.id);

  return (
    <div className="group bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 dark:border-gray-700">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={pkg.image} 
          alt={pkg.title} 
          className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-3 right-3">
            <button 
                onClick={(e) => {
                    e.preventDefault();
                    toggleBookmark(pkg.id);
                }}
                className={`p-2 rounded-full backdrop-blur-sm transition-colors ${
                    isBookmarked ? 'bg-white text-red-500' : 'bg-black/30 text-white hover:bg-white hover:text-red-500'
                }`}
            >
                <Heart size={18} className={isBookmarked ? 'fill-current' : ''} />
            </button>
        </div>
        <div className="absolute bottom-3 left-3">
             <span className="px-2 py-1 bg-brand-600 text-white text-xs font-bold rounded-md shadow-sm">
                {pkg.category}
             </span>
        </div>
      </div>
      
      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white line-clamp-1">{pkg.title}</h3>
          <div className="flex items-center text-yellow-500 text-sm font-semibold">
            <Star size={14} className="fill-current mr-1" />
            {pkg.rating}
          </div>
        </div>
        
        <p className="text-gray-500 dark:text-gray-400 text-sm mb-4 flex items-center">
            <span className="mr-2">📍 {pkg.location}</span>
        </p>

        <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm mb-4">
          <Clock size={16} className="mr-1" />
          <span>{pkg.durationDays} Days / {pkg.durationDays - 1} Nights</span>
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
          <div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Starting from</p>
            <p className="text-xl font-bold text-brand-600 dark:text-brand-400">₹{pkg.price.toLocaleString()}</p>
          </div>
          <Link 
            to={`/package/${pkg.id}`}
            className="px-4 py-2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 text-sm font-semibold rounded-lg hover:bg-brand-600 dark:hover:bg-gray-200 transition-colors"
          >
            View Deal
          </Link>
        </div>
      </div>
    </div>
  );
};

export default PackageCard;