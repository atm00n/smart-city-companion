import React, { useState } from 'react';
import { Sparkles, Send, Loader2 } from 'lucide-react';
import { generateTravelAdvice } from '../services/geminiService';

export default function AiPlanner() {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const handleAsk = async () => {
    if (!query.trim()) return;
    setLoading(true);
    const result = await generateTravelAdvice(query);
    setResponse(result);
    setLoading(false);
  };

  if (!isOpen) {
      return (
          <button 
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 z-40 bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-4 rounded-full shadow-2xl hover:scale-105 transition-transform flex items-center space-x-2"
          >
              <Sparkles size={24} />
              <span className="font-semibold hidden md:inline">Plan Trip with AI</span>
          </button>
      )
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 w-full max-w-sm bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 overflow-hidden flex flex-col max-h-[500px]">
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-4 flex justify-between items-center text-white">
        <div className="flex items-center space-x-2">
            <Sparkles size={20} />
            <h3 className="font-bold">AI Trip Assistant</h3>
        </div>
        <button onClick={() => setIsOpen(false)} className="text-white/80 hover:text-white">✕</button>
      </div>
      
      <div className="p-4 flex-1 overflow-y-auto min-h-[200px]">
        {response ? (
            <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg text-sm text-gray-800 dark:text-gray-200">
                <p>{response}</p>
                <button onClick={() => setResponse('')} className="mt-2 text-xs text-purple-600 dark:text-purple-400 font-semibold underline">Ask another question</button>
            </div>
        ) : (
            <div className="text-center text-gray-500 dark:text-gray-400 text-sm mt-8">
                <p>Ask me about hidden gems, best times to visit, or custom itineraries for India!</p>
            </div>
        )}
      </div>

      <div className="p-3 border-t border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
        <div className="flex items-center space-x-2">
            <input 
                type="text" 
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAsk()}
                placeholder="Ex: 3 days in Goa for couples..."
                className="flex-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 dark:text-white"
            />
            <button 
                onClick={handleAsk} 
                disabled={loading}
                className="bg-purple-600 text-white p-2 rounded-lg hover:bg-purple-700 disabled:opacity-50"
            >
                {loading ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
            </button>
        </div>
      </div>
    </div>
  );
}