import React, { useEffect } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Packages from './pages/Packages';
import PackageDetail from './pages/PackageDetail';
import Blog from './pages/Blog';
import BlogDetail from './pages/BlogDetail';
import Admin from './pages/Admin';
import AiItineraryPlanner from './pages/AiItineraryPlanner';
import WeatherTool from './pages/WeatherTool';
import MapExplorer from './pages/MapExplorer';
import CarRental from './pages/CarRental';
import { ThemeProvider } from './context/ThemeContext';
import { AppProvider } from './context/AppContext';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <ThemeProvider>
      <AppProvider>
        <HashRouter>
          <ScrollToTop />
          <div className="flex flex-col min-h-screen">
            <Routes>
                {/* Admin Route separate from main layout if desired, but for simplicity keeping Nav */}
                <Route path="/admin" element={<><Navbar /><Admin /></>} />
                
                {/* Main Routes */}
                <Route path="*" element={
                    <>
                        <Navbar />
                        <main className="flex-grow">
                            <Routes>
                                <Route path="/" element={<Home />} />
                                <Route path="/packages" element={<Packages />} />
                                <Route path="/package/:id" element={<PackageDetail />} />
                                <Route path="/blog" element={<Blog />} />
                                <Route path="/blog/:id" element={<BlogDetail />} />
                                <Route path="/planner" element={<AiItineraryPlanner />} />
                                <Route path="/weather" element={<WeatherTool />} />
                                <Route path="/map" element={<MapExplorer />} />
                                <Route path="/cars" element={<CarRental />} />
                            </Routes>
                        </main>
                        <Footer />
                    </>
                } />
            </Routes>
          </div>
        </HashRouter>
      </AppProvider>
    </ThemeProvider>
  );
}