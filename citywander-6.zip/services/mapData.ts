export interface Location {
    lat: number;
    lng: number;
}

export interface Attraction {
    name: string;
    description: string;
    location: Location;
}

export interface CityData {
    id: string;
    name: string;
    center: Location;
    zoom: number;
    attractions: Attraction[];
}

export const MAP_DATA: CityData[] = [
    {
        id: 'delhi',
        name: 'New Delhi',
        center: { lat: 28.6139, lng: 77.2090 },
        zoom: 12,
        attractions: [
            { name: 'India Gate', description: 'War memorial located astride the Rajpath.', location: { lat: 28.6129, lng: 77.2295 } },
            { name: 'Red Fort', description: 'Historic fort in the city of Delhi.', location: { lat: 28.6562, lng: 77.2410 } },
            { name: 'Qutub Minar', description: 'Minaret that forms part of the Qutub complex.', location: { lat: 28.5244, lng: 77.1855 } },
            { name: 'Lotus Temple', description: 'Baháʼí House of Worship notable for its flowerlike shape.', location: { lat: 28.5535, lng: 77.2588 } }
        ]
    },
    {
        id: 'mumbai',
        name: 'Mumbai',
        center: { lat: 19.0760, lng: 72.8777 },
        zoom: 12,
        attractions: [
            { name: 'Gateway of India', description: 'Arch-monument built in the early 20th century.', location: { lat: 18.9220, lng: 72.8347 } },
            { name: 'Marine Drive', description: '3.6-kilometre-long Boulevard in South Mumbai.', location: { lat: 18.944, lng: 72.823 } },
            { name: 'Chhatrapati Shivaji Terminus', description: 'Historic railway station and UNESCO World Heritage Site.', location: { lat: 18.9398, lng: 72.8354 } }
        ]
    },
    {
        id: 'jaipur',
        name: 'Jaipur',
        center: { lat: 26.9124, lng: 75.7873 },
        zoom: 13,
        attractions: [
            { name: 'Hawa Mahal', description: 'Palace of Winds, famous for its high screen wall.', location: { lat: 26.9239, lng: 75.8267 } },
            { name: 'Amber Palace', description: 'Majestic fort located in Amer, Rajasthan.', location: { lat: 26.9855, lng: 75.8513 } },
            { name: 'City Palace', description: 'Royal residence with museums and courtyards.', location: { lat: 26.9258, lng: 75.8237 } }
        ]
    },
    {
        id: 'goa',
        name: 'Goa (Panaji)',
        center: { lat: 15.4909, lng: 73.8278 },
        zoom: 11,
        attractions: [
            { name: 'Basilica of Bom Jesus', description: 'UNESCO World Heritage Site holding the remains of St. Francis Xavier.', location: { lat: 15.5009, lng: 73.9116 } },
            { name: 'Calangute Beach', description: 'The "Queen of Beaches" in Goa.', location: { lat: 15.5494, lng: 73.7535 } },
            { name: 'Fort Aguada', description: 'Well-preserved seventeenth-century Portuguese fort.', location: { lat: 15.4920, lng: 73.7737 } }
        ]
    },
    {
        id: 'bangalore',
        name: 'Bangalore',
        center: { lat: 12.9716, lng: 77.5946 },
        zoom: 12,
        attractions: [
            { name: 'Lalbagh Botanical Garden', description: 'Famous botanical garden in southern Bangalore.', location: { lat: 12.9507, lng: 77.5848 } },
            { name: 'Bangalore Palace', description: 'Royal palace known for its Tudor-style architecture.', location: { lat: 12.9988, lng: 77.5921 } },
            { name: 'Cubbon Park', description: 'Landmark \'lung\' area of the Bengaluru city.', location: { lat: 12.9757, lng: 77.5929 } }
        ]
    }
];