// Simulated AI Service - No API Key required for prototype

export const generateTravelAdvice = async (query: string): Promise<string> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1000));

  return `Here is a quick tip for "${query}": 
  
  India offers incredible diversity. For your specific query, I recommend checking local seasonal guides as the experience changes with weather. 
  
  • If visiting heritage sites, go early to beat the crowd.
  • Try local street food at busy, reputable stalls.
  • Book inter-city trains well in advance.
  
  (Simulated AI Response)`;
};

export const generateItinerary = async (destination: string, duration: string, interests: string): Promise<string> => {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));
  
    const days = parseInt(duration) || 3;
    const dest = destination.charAt(0).toUpperCase() + destination.slice(1);
    const userInterests = interests.toLowerCase();

    let itinerary = `**Trip to ${dest} (${days} Days)**\n`;
    itinerary += `*Focus: ${interests}*\n\n`;
    
    // Dynamic generation logic
    for (let i = 1; i <= days; i++) {
        itinerary += `**Day ${i}:**\n`;
        
        if (i === 1) {
            itinerary += `• Arrive in ${dest}. Check-in to your hotel/resort.\n`;
            itinerary += `• Freshen up and head out for an evening leisure walk around the city center.\n`;
            itinerary += `• Dinner at a local authentic restaurant to taste the flavors of ${dest}.\n`;
        } else if (i === days) {
            itinerary += `• Morning breakfast and souvenir shopping at the local bazaar.\n`;
            itinerary += `• Visit a cafe for a relaxing brunch.\n`;
            itinerary += `• Transfer to airport/station for departure with happy memories.\n`;
        } else {
            // Middle days logic based on simple keywords
            if (userInterests.includes('history') || userInterests.includes('culture') || userInterests.includes('heritage')) {
                 itinerary += `• Visit the main historical fort or museum of ${dest} in the morning.\n`;
                 itinerary += `• Explore ancient temples, mosques, or churches nearby.\n`;
                 itinerary += `• Take a guided heritage walk through the old town.\n`;
            } else if (userInterests.includes('food') || userInterests.includes('eat')) {
                 itinerary += `• Food tour: Start with a famous breakfast spot in ${dest}.\n`;
                 itinerary += `• Lunch at a highly-rated traditional thali place.\n`;
                 itinerary += `• Evening street food crawl to try local snacks.\n`;
            } else if (userInterests.includes('nature') || userInterests.includes('relax') || userInterests.includes('chill')) {
                 itinerary += `• Visit the botanical gardens, lake, or riverside in the morning.\n`;
                 itinerary += `• Relaxing spa session or read a book at a scenic viewpoint.\n`;
                 itinerary += `• Watch the sunset from the best vantage point in ${dest}.\n`;
            } else if (userInterests.includes('adventure') || userInterests.includes('trek')) {
                 itinerary += `• Early morning trek to a nearby hill or viewpoint.\n`;
                 itinerary += `• Participate in adventure activities available locally (rafting/ziplining/etc).\n`;
                 itinerary += `• Bonfire and camping vibes in the evening if available.\n`;
            } else {
                 // Generic
                 itinerary += `• Sightseeing tour of popular landmarks in ${dest}.\n`;
                 itinerary += `• Experience the local market hustle and buy local handicrafts.\n`;
                 itinerary += `• Visit a popular park or recreational area.\n`;
            }
        }
        itinerary += `\n`;
    }

    return itinerary;
};