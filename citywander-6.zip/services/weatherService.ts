// Simulated Weather Service
export interface WeatherData {
  city: string;
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
}

export const getSimulatedWeather = async (city: string): Promise<WeatherData> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 600));
  
  // Deterministic random generator based on city string to keep results consistent for same city
  let hash = 0;
  const str = city.toLowerCase().trim();
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const absHash = Math.abs(hash);
  
  const conditions = ['Sunny', 'Cloudy', 'Rainy', 'Partly Cloudy', 'Thunderstorm', 'Haze', 'Clear'];
  
  return {
    city: city.charAt(0).toUpperCase() + city.slice(1),
    temperature: 18 + (absHash % 22), // Range: 18°C to 40°C
    condition: conditions[absHash % conditions.length],
    humidity: 30 + (absHash % 60),    // Range: 30% to 90%
    windSpeed: 2 + (absHash % 28)     // Range: 2 km/h to 30 km/h
  };
};