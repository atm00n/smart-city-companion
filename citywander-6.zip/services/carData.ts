export interface Car {
    id: string;
    name: string;
    type: 'Hatchback' | 'Sedan' | 'SUV' | 'Luxury';
    seats: number;
    fuel: 'Petrol' | 'Diesel' | 'Electric' | 'CNG';
    transmission: 'Manual' | 'Automatic';
    pricePerDay: number;
    image: string;
    rating: number;
}

export const CAR_CITIES = [
    "New Delhi",
    "Mumbai",
    "Bangalore",
    "Goa",
    "Jaipur",
    "Chennai",
    "Kolkata",
    "Hyderabad",
    "Pune",
    "Kochi"
];

// Helper to generate consistent, offline-ready SVG car illustrations
const getCarSvg = (type: string, color: string, bg: string) => {
    const encodedBg = encodeURIComponent(bg);
    const encodedColor = encodeURIComponent(color);
    
    let path = "";
    // Simple stylized paths for different car types
    if (type === 'Hatchback') {
        path = `M200,320 L600,320 L580,200 L250,200 L200,320 Z M260,210 L390,210 L390,270 L250,270 Z M410,210 L560,210 L570,270 L410,270 Z`;
    } else if (type === 'SUV') {
        path = `M180,320 L620,320 L600,180 L220,180 L180,320 Z M240,190 L390,190 L390,260 L230,260 Z M410,190 L580,190 L590,260 L410,260 Z`;
    } else {
        // Sedan/Luxury
        path = `M150,330 L650,330 L600,220 L250,220 L150,330 Z M280,230 L410,230 L410,280 L260,280 Z M430,230 L570,230 L580,280 L430,280 Z`;
    }

    return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500" preserveAspectRatio="xMidYMid slice"><rect width="800" height="500" fill="${encodedBg}"/><path fill="${encodedColor}" d="${path}"/><circle cx="260" cy="330" r="55" fill="%23334155"/><circle cx="540" cy="330" r="55" fill="%23334155"/><circle cx="260" cy="330" r="25" fill="%2394a3b8"/><circle cx="540" cy="330" r="25" fill="%2394a3b8"/><text x="400" y="450" font-family="sans-serif" font-weight="bold" font-size="24" text-anchor="middle" fill="%2394a3b8" letter-spacing="2">${type.toUpperCase()}</text></svg>`;
};

export const MOCK_CARS: Car[] = [
    {
        id: 'c1',
        name: 'Maruti Suzuki Swift',
        type: 'Hatchback',
        seats: 4,
        fuel: 'Petrol',
        transmission: 'Manual',
        pricePerDay: 1500,
        image: getCarSvg('Hatchback', '#ef4444', '#fee2e2'), // Red on Light Red
        rating: 4.5
    },
    {
        id: 'c2',
        name: 'Hyundai i20',
        type: 'Hatchback',
        seats: 4,
        fuel: 'Diesel',
        transmission: 'Automatic',
        pricePerDay: 1800,
        image: getCarSvg('Hatchback', '#3b82f6', '#dbeafe'), // Blue on Light Blue
        rating: 4.6
    },
    {
        id: 'c3',
        name: 'Honda City',
        type: 'Sedan',
        seats: 5,
        fuel: 'Petrol',
        transmission: 'Automatic',
        pricePerDay: 2500,
        image: getCarSvg('Sedan', '#64748b', '#f1f5f9'), // Grey on Slate
        rating: 4.8
    },
    {
        id: 'c4',
        name: 'Maruti Dzire',
        type: 'Sedan',
        seats: 5,
        fuel: 'CNG',
        transmission: 'Manual',
        pricePerDay: 2000,
        image: getCarSvg('Sedan', '#f59e0b', '#fef3c7'), // Orange on Amber
        rating: 4.3
    },
    {
        id: 'c5',
        name: 'Mahindra Thar',
        type: 'SUV',
        seats: 4,
        fuel: 'Diesel',
        transmission: 'Manual',
        pricePerDay: 4500,
        image: getCarSvg('SUV', '#1f2937', '#e5e7eb'), // Dark on Gray
        rating: 4.9
    },
    {
        id: 'c6',
        name: 'Hyundai Creta',
        type: 'SUV',
        seats: 5,
        fuel: 'Diesel',
        transmission: 'Automatic',
        pricePerDay: 3200,
        image: getCarSvg('SUV', '#059669', '#d1fae5'), // Green on Mint
        rating: 4.7
    },
    {
        id: 'c7',
        name: 'Toyota Innova Crysta',
        type: 'SUV',
        seats: 7,
        fuel: 'Diesel',
        transmission: 'Manual',
        pricePerDay: 4000,
        image: getCarSvg('SUV', '#7c3aed', '#ede9fe'), // Purple on Violet
        rating: 4.8
    },
    {
        id: 'c8',
        name: 'Mercedes Benz C-Class',
        type: 'Luxury',
        seats: 5,
        fuel: 'Petrol',
        transmission: 'Automatic',
        pricePerDay: 8500,
        image: getCarSvg('Luxury', '#000000', '#e2e8f0'), // Black on Silver
        rating: 4.9
    }
];